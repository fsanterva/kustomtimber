<?php get_header(); ?>
<div id="beforemain_wrap">
<main id="main-areaarticle" class="404page">
  <article id="main-area">
    <section class="section_404page">
      <div class="row">
        <h1>
          404 Page<span>.</span>
        </h1>
        <h2>
          The url you're trying to access cannot be found
        </h2>
      </div>
    </section>
  </article>
</main>
<?php get_footer(); ?>