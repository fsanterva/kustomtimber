<?php

class Forminator_Calculator_Exception extends Exception {
}
